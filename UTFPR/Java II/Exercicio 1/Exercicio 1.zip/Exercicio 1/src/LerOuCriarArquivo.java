import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class LerOuCriarArquivo {

    public static void verify() {

        Scanner scanner = new Scanner(System.in);

        System.out.print("\nInforme o nome do arquivo: ");
        String fileName = scanner.nextLine();

        System.out.println("Escreva algo para colocar no arquivo: ");
        String str = scanner.nextLine();

        File file = new File(fileName);
        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, true))){

            if(file.exists()){
                bufferedWriter.write(str+"\n");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void verifyWithSwing() {

        String str = JOptionPane.showInputDialog("Informe o nome do arquivo");

        JFileChooser jFileChooser = new JFileChooser();
        jFileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        int result = jFileChooser.showSaveDialog(null);

        if (result == JFileChooser.CANCEL_OPTION) {
            return;
        }

        File fileName = new File(str);

        jFileChooser.setCurrentDirectory(fileName);

        if (fileName == null || fileName.getName().equals("")) {
            JOptionPane.showMessageDialog(null, "Nome de Arquivo Inválido", "Nome de Arquivo Inválido", JOptionPane.ERROR_MESSAGE);
        }else{

            str = JOptionPane.showInputDialog("Informe o que você quer escrever no arquivo");

            try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(fileName, true))){

                if(fileName.exists()){
                    bufferedWriter.write(str+"\n");
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }
}
