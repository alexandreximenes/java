import java.io.File;
import java.util.Arrays;

public class ListaArquivosDiretorios {

    public static void inciarLeitura() {

        String pathname = "C:\\";
        File file = new File(pathname);
        System.out.println("Listando arquivos e pastas do diretorio: " + pathname);

        if (file.exists()) {

            if (file.isDirectory()) {
                listarDiretorio(file);
            } else {
                imprimirArquivo(file);
            }

        } else {
            System.out.println(pathname + " não encontrado");
        }

    }

    private static void imprimirArquivo(File file) {
        System.out.println(file + " é um arquivo");
    }

    private static void listarDiretorio(File file) {

        if (file.exists() && file.isDirectory()) {

            File[] files = file.listFiles();

            if (files != null) {
                Arrays.stream(files).forEach(l -> {
                    if (l.exists() && l.isDirectory()) {
                        System.out.printf("- %s (é um diretório) link: %s \n\n", l.getName(), l.getAbsolutePath());
                        listarDiretorio(l);
                    } else {
                        System.out.printf("\t- %s (é um arquivo) - %s \n", l.getName(), l.getAbsoluteFile());
                    }
                });
            }
        }
    }
}
