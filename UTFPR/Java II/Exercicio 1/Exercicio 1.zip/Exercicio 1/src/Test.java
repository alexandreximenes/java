import java.util.Scanner;

public class Test {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("1) Listar arquivos e pastas do diretório raiz");
        System.out.println("2) Criar ou editar arquivo");
        System.out.println("3) Criar ou editar arquivo com interface grafica");

        String read = scanner.nextLine();

        switch (read) {

            case "1":
                System.out.println("Opção 1) - Listando arquivos e pastas do diretório raiz");
                ListaArquivosDiretorios.inciarLeitura();
                break;

            case "2":
                System.out.println("Opção 2) - Criar ou editar arquivo");
                LerOuCriarArquivo.verify();
                break;

            case "3":
                System.out.println("Opção 3) - Criar ou editar arquivo com interface grafica");
                LerOuCriarArquivo.verifyWithSwing();
                break;
        }

    }

}
