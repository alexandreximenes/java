-- -----------------------------------------------------
--  Criando user funcionario
-- ----------------------------------------------------
DROP USER IF EXISTS 'funcionario'@'localhost';
CREATE USER 'funcionario'@'localhost' IDENTIFIED BY 'funcionario';
GRANT INSERT ON exercicio2.* TO 'funcionario'@'localhost';
GRANT INSERT ON exercicio2.* TO 'funcionario'@'localhost';

-- -----------------------------------------------------
--  Criando user gerente
-- ----------------------------------------------------
DROP USER IF EXISTS 'gerente'@'localhost';
CREATE USER 'gerente'@'localhost' IDENTIFIED BY 'gerente';
GRANT ALL PRIVILEGES ON exercicio2.* TO 'gerente'@'localhost';
