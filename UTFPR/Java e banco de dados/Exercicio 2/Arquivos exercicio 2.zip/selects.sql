
-- -----------------------------------------------------
-- 1 - Mostre o nome do departamento que tem o maior número de funcionários, 
-- mostrando também a quantidade de funcionários desse departamento. 
-- -----------------------------------------------------
select d.nome, count(f.departamento_codigo) as total_por_departamento from funcionario f, departamento d
where d.codigo = f.departamento_codigo
group by  d.nome
order by total_por_departamento desc
limit 1;

-- select count(*) from funcionario f where f.departamento_codigo = 1 -- 111

-- -----------------------------------------------------
-- 2 - Mostre o nome do departamento que tem a menor quantidade de funcionários sem dependentes, 
-- com a quantidade de funcionários. 
-- -----------------------------------------------------
select d.nome, count(f.departamento_codigo) as total_por_departamento from funcionario f, departamento d
where d.codigo = f.departamento_codigo
and f.quantidade_dependentes is null
group by  d.nome
order by total_por_departamento asc
limit 1;

-- -----------------------------------------------------
--  3 - Mostre o nome do departamento com os nomes dos seus respectivos funcionários de todos os 
-- departamentos cujo nome começa com “DIR”.
-- -----------------------------------------------------
select d.nome, f.nome from funcionario f, departamento d
where d.codigo = f.departamento_codigo
and d.nome like 'dir%';

-- -----------------------------------------------------
--  4 - Mostre o nome do funcionário e do departamento ao qual pertence o funcionário com o maior salário
-- ----------------------------------------------------
select d.nome, f.nome, max(f.salario) as salario_maximo from funcionario f, departamento d
where d.codigo = f.departamento_codigo
group by f.nome
order by salario_maximo desc
limit 1;

-- -----------------------------------------------------
--  5 - Mostre o nome do departamento e do funcionário de cada departamento que tem o cargo de “Gerente”. 
-- ----------------------------------------------------
select d.nome, f.nome from funcionario f, departamento d
where d.codigo = f.departamento_codigo
and f.cargo = 'Gerente';
