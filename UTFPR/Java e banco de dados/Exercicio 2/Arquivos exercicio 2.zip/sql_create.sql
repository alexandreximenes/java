CREATE SCHEMA IF NOT EXISTS `exercicio2` DEFAULT CHARACTER SET utf8 ;
USE `exercicio2`;

-- -----------------------------------------------------
-- Table `exercicio2`.`departamento`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `exercicio2`.`departamento` (
  `codigo` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NULL,
  PRIMARY KEY (`codigo`));
  
-- -----------------------------------------------------
-- Table `exercicio2`.`funcionario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `exercicio2`.`funcionario` (
  `codigo` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NULL,
  `quantidade_dependentes` INT NULL,
  `salario` DECIMAL(10,2) NULL,
  `cargo` VARCHAR(45) NULL,
  `departamento_codigo` INT NOT NULL,
  CONSTRAINT `fk_departamento_funcionario`
    FOREIGN KEY (`departamento_codigo`)
    REFERENCES `exercicio2`.`departamento` (`codigo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  PRIMARY KEY (`codigo`, `departamento_codigo`))
ENGINE = InnoDB;