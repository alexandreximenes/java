package com.mycompany.exercicio5.projection;

public interface CidadeTotal {
    String getCidade();
    Long getTotal();
}
