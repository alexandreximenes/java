package com.mycompany.exercicio5.projection;

public interface SemEndereco {
    String getNome();
    String getIdade();
    String getDtCadastro();
}
