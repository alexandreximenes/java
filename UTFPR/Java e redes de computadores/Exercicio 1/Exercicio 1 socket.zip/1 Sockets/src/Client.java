import javax.swing.*;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Objects;

public class Client {

    private static Socket socket;
    private static DataInputStream entrada;
    private static DataOutputStream saida;

    public static void main(String[] args) throws IOException {

     try{

         socket = new Socket("127.0.0.1", 5000);

         entrada = new DataInputStream(socket.getInputStream());
         saida = new DataOutputStream(socket.getOutputStream());

         String cpf = JOptionPane.showInputDialog("Informe um CPF: ");
         cpf = cpf.replaceAll("(\\D)", "");
         if(Objects.nonNull(cpf) && cpf.length() == 11){
             saida.writeUTF(cpf);
         }else{
             JOptionPane.showMessageDialog(null, "Informe um cpf com 11 numeros");
         }

         Boolean cpfValidado = entrada.readBoolean();

         if(cpfValidado)
             JOptionPane.showMessageDialog(null, "Cpf validado com sucesso!");
         else
             JOptionPane.showMessageDialog(null, "Cpf invalido!");

     }catch (Exception e){
         e.printStackTrace();
     }

    }
}
