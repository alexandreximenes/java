import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    private static Socket socket;
    private static ServerSocket serverSocket;
    private static DataInputStream entrada;
    private static DataOutputStream saida;

    public static void main(String[] args) throws IOException {

        try {

            System.out.println("Servidor escutando na porta 5000");
            serverSocket = new ServerSocket(5000);
            socket = serverSocket.accept();

            entrada = new DataInputStream(socket.getInputStream());
            saida = new DataOutputStream(socket.getOutputStream());

            String cpf = entrada.readUTF();
            System.out.printf("Servidor recebeu CPF (%s)", cpf);
            Boolean result = Valida.cpf(cpf);

            saida.writeBoolean(result);

        } catch (IOException e) {
            e.printStackTrace();
            saida.writeBoolean(false);
        }
    }
}
