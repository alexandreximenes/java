
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class Servidor extends Thread {
    
    private Socket socket;
    
    public Servidor(Socket conexao) {
        this.socket = conexao;
    }
    
    @Override
    public void run() {
        
        try {
            DataInputStream entrada = new DataInputStream(socket.getInputStream());
            
            while(true){
                String frase = entrada.readUTF();
                System.out.println("Cliente (" + Thread.currentThread().getId() + ") digitou: " +frase);
            }

        } catch(Exception e) {
            System.out.println("Cliente ("+ Thread.currentThread().getId()+ ") se desconectou!");
        }
        
    }
    
    public static void main(String[] args) {
        
        try {
        
            ServerSocket server = new ServerSocket(5000);
            System.out.println("Servidor escutando na porta 5000");
            
            while(true) {
                
                Socket conexao = server.accept();
                Servidor sThread = new Servidor(conexao);
                System.out.println("Algum cliente se conectou..." + conexao.getInetAddress().getHostAddress());
                sThread.start();
                
            }
        
        } catch(Exception e) {
            
        }
        
    }
    
}
