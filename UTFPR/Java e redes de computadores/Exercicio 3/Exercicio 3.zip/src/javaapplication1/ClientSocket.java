package javaapplication1;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ClientSocket {

    private Socket socket;
    private DataInputStream entrada;
    private ObjectOutputStream saida;

    boolean send(Client client) {

        try {

            socket = new Socket("127.0.0.1", 5000);
            System.out.println("Enviando dados...");
            saida = new ObjectOutputStream(socket.getOutputStream());
            saida.writeObject(client);

            System.out.println("recebendo retorno dos dados...");
            entrada = new DataInputStream(socket.getInputStream());
            boolean success = entrada.readBoolean();

            socket.close();
            if(success){
                return true;
            }else{
                return false;
            }



        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);

        }

        return false;
    }
}
