/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 * @author xiiim
 */
public class Server {


    private String nome;
    private Integer idade;
    private static Socket socket;
    private static ObjectInputStream entrada;
    private static DataOutputStream saida;


    Server(String nome, Integer idade) {
        this.nome = nome;
        this.idade = idade;
    }


    public static void main(String[] args) {

        try {
            ServerSocket server = new ServerSocket(5000);
            System.out.println("Servidor escutando na porta 5000");
            socket = server.accept();

            entrada = new ObjectInputStream(socket.getInputStream());
            saida = new DataOutputStream(socket.getOutputStream());

            try {
                System.out.println("recebendo dados do cliente...");
                Client client = (Client) entrada.readObject();
                if (client != null) {
                    saida.writeBoolean(true);
                } else {
                    saida.writeBoolean(false);
                }


            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }

        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


}
