/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.io.*;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author xiiim
 */
public class Client implements Serializable {

    private static final long serialVersionUID = 1L;
        
    private String nome;
    private Integer idade;


    Client(String nome, Integer idade) {
       this.nome = nome;
       this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getIdade() {
        return idade;
    }

    public void setIdade(Integer idade) {
        this.idade = idade;
    }

    boolean sendData() {

        return new ClientSocket().send(this);
    }
    
}
